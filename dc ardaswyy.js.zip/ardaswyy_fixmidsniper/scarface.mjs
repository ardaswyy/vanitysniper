"use strict";

import tls from 'tls';
import WebSocket from 'ws';
import extractJsonFromString from 'extract-json-from-string';
import colors from 'colors';
import http2 from 'http2';
import axios from 'axios';

const config = {
    discordHost: "canary.discord.com",
    webhook: "https://discord.com/api/webhooks/1358207288392945945/GvJTnw1k44cCQph1ZqYJA2V_N0P-dIyxfJqm00OzylMnBkKO8m9oqtbcJIpVDkub4lyk",
    password: "Ardam145334",
    discordToken: "MTM1ODE5NjI5NDI1ODAwNDAzOQ.GS028C.yQuN6w-WnEAchO0yn1RkCf83tSBEKSF4KxFZGs",
    guildId: "1345677288540340305",
    gatewayUrl: "wss://gateway.discord.gg/?v=9&encoding=json",
    os: "Windows",
    browser: "Chrome",
    device: "Desktop"
};

let mfaToken;
const guilds = {};

const tlsSocket = tls.connect({ host: config.discordHost, port: 443 });

tlsSocket.on("data", async (data) => {
    try {
        const ext = extractJsonFromString(data.toString());
        const find = ext.find((e) => e.code) || ext.find((e) => e.message);
        if (find) console.log(find);
    } catch (err) {
        console.error("Data Parse Error:", err);
    }
});

tlsSocket.on("error", (error) => {
    console.log(`TLS Error:`, error);
    process.exit();
});

tlsSocket.on("end", () => {
    console.log("TLS connection closed");
    process.exit();
});

tlsSocket.on("secureConnect", () => {
    const websocket = new WebSocket(config.gatewayUrl);

    websocket.onclose = (event) => {
        console.log(`WebSocket closed: ${event.reason} (${event.code})`);
        process.exit();
    };

    websocket.onmessage = async (message) => {
        const { d, op, t } = JSON.parse(message.data);

        if (t === "GUILD_UPDATE") {
            const oldVanity = guilds[d.guild_id];
            if (oldVanity && oldVanity !== d.vanity_url_code) {
                console.log(`Vanity değişmiş: ${oldVanity} -> ${d.vanity_url_code}`);
                await notifyWebhook(oldVanity);
                guilds[d.guild_id] = d.vanity_url_code;
            }
        }

        if (t === "READY") {
            d.guilds.forEach((guild) => {
                if (guild.vanity_url_code) {
                    guilds[guild.id] = guild.vanity_url_code;
                    console.log(colors.magenta(`Guild: ${guild.id}`), colors.cyan(`Vanity: ${guild.vanity_url_code}`));
                }
            });
        }

        if (op === 10) {
            websocket.send(JSON.stringify({
                op: 2,
                d: {
                    token: config.discordToken,
                    intents: 513,
                    properties: {
                        os: config.os,
                        browser: config.browser,
                        device: config.device,
                    }
                }
            }));

            setInterval(() => websocket.send(JSON.stringify({ op: 1, d: null })), d.heartbeat_interval);
        }

        if (op === 7) {
            console.log("Reconnect OP7");
            process.exit();
        }
    };
});

async function notifyWebhook(vanity) {
    try {
        await axios.post(config.webhook, {
            content: `Vanity URL değişti: ${vanity}`
        });
    } catch (error) {
        console.error('Webhook gönderilemedi:', error);
    }
}

process.title = "Zafer Allah'ın Yanında Olanındır..!";

